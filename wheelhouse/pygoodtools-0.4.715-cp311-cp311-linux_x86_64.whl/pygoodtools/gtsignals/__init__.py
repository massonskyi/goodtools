from .Signal import Signal

__all__ = ['pyGTSignal']

pyGTSignal = Signal